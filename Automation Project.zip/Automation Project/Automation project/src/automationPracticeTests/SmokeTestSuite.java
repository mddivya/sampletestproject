package automationPracticeTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class SmokeTestSuite {

    public static void main(String[] args) {
    //Test Data
    String baseURL = "http://automationpractice.com/index.php";
    String username = "testaccount@mailinator.com";
    String password = "Password1";
    //create the browser profile and provide the path
        System.setProperty("webdriver.chrome.driver","src/browserFiles/chromedriver");
        //Instantiating the webDirver variable and assign the webDriver object
        WebDriver driver;
        driver = new ChromeDriver();

        //opening the URL
        driver.get(baseURL);

        //click signIn link
        //identify the webElement of signIn link
        WebElement signInLink = driver.findElement(By.cssSelector(".login"));
        //click the signIn link
        signInLink.click();

        //wait for page to load
//        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);

        //enter the user name
        WebElement usernameField = driver.findElement(By.cssSelector("#email"));
        usernameField.sendKeys(username);
        //enter the password
        WebElement passwordField = driver.findElement(By.cssSelector("#passwd"));
        passwordField.sendKeys(password);
        //click the login button
        WebElement loginButton = driver.findElement(By.cssSelector("#SubmitLogin"));
        loginButton.click();
        //close the browser
        driver.close();

    }
}
