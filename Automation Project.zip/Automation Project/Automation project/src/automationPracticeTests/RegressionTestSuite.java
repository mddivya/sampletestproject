package automationPracticeTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

public class RegressionTestSuite {
    //Test Data
    static String baseURL = "http://automationpractice.com/index.php";
    static String email1 = "divyamd@gmail.com";
    static String email2 = "divya@gmail.com";
    static String email3 = "mddivya@gmail.com";
    static String firstName = "Divya";
    static String title = "Ms";
    static String dobDay = "24 ";
    static String dobMonth = "September ";
    static String dobYear = "1995  ";
    static String stateName = "Alaska";

    //Instantiating the webDirver variable and assign the webDriver object
    static WebDriver driver;

    //ReUsable Methods
    public void openBrowser() {
//   i. Open browser
//  create the browser profile and provide the path
        System.setProperty("webdriver.chrome.driver", "src/browserFiles/chromedriver");
        driver = new ChromeDriver();
//        ii. Enter url
        driver.get(baseURL);
//        iii. Wait for page load
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }


    public void navigateToRegisterPage() {
        //        iv. Select signIn link
        WebElement signInLink = driver.findElement(By.cssSelector(".login"));
        signInLink.click();
//        v. Wait for page load
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    public void enterEmailAndContinue(String userEmail) {
        //        vii. Enter the email address and select create account button
        WebElement newAccountEmail = driver.findElement(By.cssSelector("#email_create"));
        newAccountEmail.sendKeys(userEmail);

        WebElement createAccountButton = driver.findElement(By.cssSelector("#SubmitCreate"));
        createAccountButton.click();
        //        viii. Wait for page load
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    public void selectTitle(String title) {
        //        x. Select the title
        if (title == "Ms") {
            WebElement title1 = driver.findElement(By.cssSelector("#id_gender1"));
            title1.click();
        } else if (title == "Mrs") {
            WebElement title2 = driver.findElement(By.cssSelector("#id_gender2"));
            title2.click();
        }
    }

    public void enterFirstName(String firstname) {
        //        Enter the first name
        WebElement firsrNameField = driver.findElement(By.cssSelector("[name='customer_firstname']"));
        firsrNameField.sendKeys(firstname);
    }

    public void enterDOB(String day, String month, String year) {
        //        select DOBDate(day and month and year)
        WebElement DOBDate = driver.findElement(By.cssSelector("#days"));
        Select dayList = new Select(DOBDate);
        dayList.selectByVisibleText(day);

//        select DOBMonth(day and month and year)
        WebElement DOBMonth = driver.findElement(By.cssSelector("#months"));
        Select monthList = new Select(DOBMonth);
        monthList.selectByVisibleText(month);

//        select DOBYear(day and month and year)
        WebElement DOBYear = driver.findElement(By.cssSelector("#years"));
        Select yearList = new Select(DOBYear);
        yearList.selectByVisibleText(year);

    }


    public void selectState(String state) {
        //        Select the state
        WebElement stateField = driver.findElement(By.cssSelector("#id_state"));
        Select stateList = new Select(stateField);
        stateList.selectByVisibleText(state);
    }

    public void submitRegistrationForm() {
        //        xi.  click register button
        WebElement registerButton = driver.findElement(By.cssSelector("#submitAccount"));
        registerButton.click();
    }

    public void selectNewsLetter() {
        WebElement newsLetterCheckBox = driver.findElement(By.cssSelector("#newsletter"));
        newsLetterCheckBox.click();
    }
    public static void main(String[] args) {
        //Testcase - I
        RegressionTestSuite regressionTestSuite = new RegressionTestSuite();
        regressionTestSuite.openBrowser();
        regressionTestSuite.navigateToRegisterPage();
        //        vi. Verify that user is on the Authentication page - TODO
        regressionTestSuite.enterEmailAndContinue(email1);
//        ix. Verify that user is on the registration page
        regressionTestSuite.selectTitle(title);
        regressionTestSuite.enterFirstName(firstName);
        regressionTestSuite.enterDOB(dobDay, dobMonth, dobYear);
        regressionTestSuite.selectNewsLetter();
        regressionTestSuite.selectState(stateName);
        regressionTestSuite.submitRegistrationForm();
//        xii.  Verify that user will see validation messages on the page
        driver.close();

        //Testcase - II
        regressionTestSuite.openBrowser();
        regressionTestSuite.navigateToRegisterPage();
        //        vi. Verify that user is on the Authentication page - TODO
        regressionTestSuite.enterEmailAndContinue(email2);
//        ix. Verify that user is on the registration page
        regressionTestSuite.selectTitle("Mr");
        regressionTestSuite.enterFirstName("Venu");
        regressionTestSuite.enterDOB("2  ", "May ", "1999  ");
        regressionTestSuite.selectNewsLetter();
        regressionTestSuite.selectState("Alabama");
        regressionTestSuite.submitRegistrationForm();
//        xii.  Verify that user will see validation messages on the page
    }


}
